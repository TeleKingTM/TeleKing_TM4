do local _ = {
  Group_rate = "5/5",
  Supergroup_rate = "10/10",
  about_text = "    \nThis Is An Original Bot And Based On (AntiSpam , Version 4 Final).\n\nCopyright All Right Reserved And You Must Respect All Laws.\n\nClone : https://bitbucket.org/AntiSpam99/AntiSpam_TM3.git\n\nNote : This Is One Of My Private Repositoies\n\nFor Buying It You Should Contact Me \n\nجهت سفارش ساخت یا خرید ربات و نصب بر روی سرور با آیدی یا شماره زیر در ارتباط باشید\n\nCreator : @To_My_Amigos\n\nPhone Number : +989213985504\n\nOur Channel : @AntiSpam_TM\n\nJoin Us .\n\n",
  disabled_channels = {
    ["channel#id1054628471"] = false,
    ["channel#id1055430347"] = false
  },
  enabled_plugins = {
    "all",
    "anti_bot",
    "anti_spam",
    "banhammer",
    "broadcast",
    "chat",
    "cleandeleted",
    "clear_members",
    "dler",
    "help",
    "info",
    "invite",
    "lock_badwords",
    "lock_emoji",
    "lock_english",
    "lock_username",
    "mute-all",
    "on_off",
    "plugins",
    "price",
    "private",
    "rmsg",
    "security",
    "sudo",
    "supergroup",
    "time",
    "tools",
    "weather",
    "whitelist",
    "wlc_and_bye"
  },
  moderation = {
    data = "data/moderation.json"
  },
  sudo_users = {
    270595585,
    0,
    0
  },
  support_gp = 