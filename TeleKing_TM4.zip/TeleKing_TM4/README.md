*---------------------------------------------------------*
*---------------------------------------------------------*

## AntiSpam_TM

## By Kia Pashang

## This Is An Original Bot And Based On (AntiSpam , Version 4 Final).

## Copyright All Right Reserved And You Must Respect All Laws.

## Clone : https://bitbucket.org/AntiSpam99/AntiSpam_TM4.git

## Note : This Is One Of My Private Repositoies

## For Buying It You Should Contact ME 

## جهت سفارش ساخت یا خرید ربات و نصب بر روی سرور با آیدی یا شماره زیر در ارتباط باشید

## Creators Telegram ID : @To_My_Amigos

## Phone Number : +989213985504

## Our Channel : @AntiSpam_TM

*----------------------------------------------------------*		
*----------------------------------------------------------*


## You can create an account for free in:
|Rank | Name | Adress |
|:--------|:----------|:------------|
| <h4>`Rank` _(1)_ | Codenvy | [https://codenvy.com](https://codenvy.com) |
| <h4>`Rank` _(2)_ | Codeanywhere | [https://codeanywhere.com](https://codeanywhere.com) |
| <h4>`Rank` _(3)_ | Cloud9 | [https://C9.io](https://C9.io) |
| <h4>`Rank` _(4)_ | Koding | [https://koding.com](https://koding.com) |
| <h4>`Rank` _(5)_ | SourceLair | [https://www.sourcelair.com/home](https://www.sourcelair.com) |
| <h4>`Rank` _(6)_ | Nitrous | [https://www.nitrous.io/](https://www.nitrous.io) |

##Strong management:
- <p align="left">Lock Links
- <p align="left">Lock Spam
- <p align="left">Lock Flood
- <p align="left">Lock Bots
- <p align="left">Lock Forward
- <p align="left">Lock Reply
- <p align="left">Lock Share
- <p align="left">Lock Tag
- <p align="left">Lock Number
- <p align="left">Lock Emoji
- <p align="left">Lock Media
- <p align="left">Lock Documents
- <p align="left">Lock Audio
- <p align="left">Lock Video
- <p align="left">Lock Photo
- <p align="left">Lock Gifs
- <p align="left">Lock All
- <p align="left">Lock English
- <p align="left">Lock Arabic/Persian
- <p align="left">Lock Text
- <p align="left">Lock Badwords
- <p align="left">Lock Inline
- <p align="left">Lock Cmd
- <p align="left">Lock Sticker
- <p align="left">Lock Rtl
- <p align="left">Lock Strict
- <p align="left">Lock Tgservice
- <p align="left">Muteuser And Unmuteuser
- <p align="left">Clean Members
- <p align="left">Clean Deleted
- <p align="left">Time
- <p align="left">Muteall
- <p align="left">Muteall (H) (M) (S) 
- <p align="left">Public & Members
- <p align="left">And ...



| INSTALL BOT |
|:-----------------------|
- <p align="left">Clone Source:
```sh
git clone https://bitbucket.org/AntiSpam99/AntiSpam_TM4.git && cd AntiSpam_TM4
```
- <p align="left">install bot:
```sh
chmod 777 start.sh
./start.sh install
y
```
| ANTI CRASH |
|:-----------------------|
```sh
tmux new-session -s script "bash steady.sh -t"
```
- <p align="left">Now run your bot then enter bot's phone number and join code:
`./start.sh -q`
- <p align="left">And you can start bot with steady script:

| FREE SERVER: |
|:-----------------------|
| `./steady.sh -t` |

| BOUGHT SERVER: |
|:-----------------------|
| `screen ./steady.sh -t` |
| Or |
| `nohup ./start.sh` |

